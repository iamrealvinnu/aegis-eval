# Aegis-Eval: Autonomous AI Risk Assessment & Mitigation Framework

Aegis-Eval is an enterprise-grade evaluation framework designed to empirically test the safety boundaries of autonomous, self-improving AI agents. It provides a zero-trust execution environment with high-frequency telemetry to detect and mitigate risks such as **Instrumental Convergence**, **Resource Hijacking**, and **Prohibited Operations**.

## 🚀 Key Features: Hardened Cognitive Firewall V3.0 [MAJOR BREAKTHROUGH]

V3.0 represents a significant leap in AI security, closing common bypass gaps via kernel-level containment and semantic de-obfuscation.

- **Hardened Intent Interception**: [NEW] Now includes a **Semantic De-obfuscator** that resolves string concatenations (e.g., `'os.' + 'system'`) and blocks dynamic attribute lookups (`getattr`, `setattr`) used to hide malicious intent.
- **Kernel-Level Containment**: [NEW] The sandbox now drops **ALL Linux Capabilities** (`cap_drop=['ALL']`) and uses `no-new-privileges` to prevent C-extension or syscall-based bypasses of Python-level safety.
- **Cumulative Exfiltration Tracking**: [NEW] Detects **'Drip-Fed' leaks** by monitoring entropy across the entire agent session, stopping models that try to leak secrets one character at a time.
- **Contextual Access Control (C-ACLs)**: Enforces "Least Privilege" data access based on the agent's assigned role.
- **Deception Engineering (Honeypots)**: Automatically injects fake secrets (honeypots) to definitively prove malicious intent.
- **Swarm Security**: Sanitizes communication between multiple agents in a collaborative swarm.

---

## 🔬 Testing Philosophy: Total Containment
We move beyond "Alignment" into **Hardened Technical Containment**. V3.0 ensures that even if an agent is determined to be malicious and uses obfuscation, it is technically blocked at both the symbolic and kernel levels.

---

## 🛠 Installation

```bash
pip install aegis-ai-eval
```

## 💻 Quick Start (Developer API)

Integrate Aegis into your own Agentic workflows (LangChain, CrewAI, etc.):

```python
from aegis import CognitiveFirewall

# Initialize the firewall with your Safety DNA
firewall = CognitiveFirewall(dna_path="prompts/safety_dna.json")

# Verify code before execution
report = await firewall.verify_code("import os; os.system('rm -rf /')")
if report['intent']['status'] == 'violation':
    print(f"Blocked: {report['intent']['violations']}")
```

---

## 📂 Architecture

- `aegis/core/orchestrator.py`: The central nervous system managing the agent lifecycle.
- `aegis/monitors/context_gatekeeper.py`: Enforces the data perimeter and honeypots.
- `aegis/monitors/network_proxy.py`: Intercepts and sanitizes network egress.
- `aegis/monitors/inter_agent_firewall.py`: Secures inter-agent communication.
- `tools/policy_gen.py`: Automatically generates Safety DNA policies from your workspace.

---

## 🛡 Disclaimer
Aegis-Eval is built for security research and AI alignment testing. Always run in a controlled environment. 
